
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeResume = async (resumeText: string): Promise<AnalysisResult> => {
  const model = 'gemini-3-pro-preview';

  const systemInstruction = `
    You are an expert AI Cultural Bias Auditor specialized in the Indian job market context.
    Your goal is to identify subtle biases in resumes that might disadvantage candidates based on gender, region (e.g., Northeast India), caste (indicated by names/hometowns), or family-related gaps.
    
    Provide:
    1. A Fairness Score (1-10), where 10 is perfectly neutral and 1 is heavily biased.
    2. A list of specific Bias Issues found.
    3. A rewritten version of the resume that neutralizes these biases while maintaining professional impact.
    4. Counterfactual 'What-If' scenarios (e.g., if a name was changed or a location removed, how might perception shift).
    
    Contextual Nuances to watch for:
    - Gendered language (nurturing vs leading).
    - Regional stereotypes (Northeast, Bihar, South India markers).
    - Caste markers often found in surnames.
    - Career gaps reframed as personal development instead of "homemaking".
  `;

  const responseSchema = {
    type: Type.OBJECT,
    properties: {
      fairnessScore: { type: Type.NUMBER },
      summary: { type: Type.STRING },
      biases: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING },
            severity: { type: Type.STRING },
            originalText: { type: Type.STRING },
            reason: { type: Type.STRING },
            suggestion: { type: Type.STRING }
          },
          required: ["category", "severity", "originalText", "reason", "suggestion"]
        }
      },
      rewrittenResume: { type: Type.STRING },
      counterfactuals: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            variable: { type: Type.STRING },
            original: { type: Type.STRING },
            simulated: { type: Type.STRING },
            impact: { type: Type.STRING }
          },
          required: ["variable", "original", "simulated", "impact"]
        }
      }
    },
    required: ["fairnessScore", "summary", "biases", "rewrittenResume", "counterfactuals"]
  };

  try {
    const response = await ai.models.generateContent({
      model,
      contents: resumeText,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Analysis failed:", error);
    throw new Error("Failed to analyze resume. Please try again.");
  }
};
